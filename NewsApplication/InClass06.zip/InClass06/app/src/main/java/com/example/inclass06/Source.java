package com.example.inclass06;

public class Source {

    String id;
    String name;
}
